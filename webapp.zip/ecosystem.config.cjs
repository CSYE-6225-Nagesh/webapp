module.exports = {
  apps: [
    {
      name: "webapp",
      script: "npm",
      args: "start",
    },
  ],
};
